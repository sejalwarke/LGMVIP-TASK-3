# LGM-Task3 : Intermediate Level Task
Student Registration Form Whose Data Display In Same Page Using HTML,CSS & JS.
